(function($) {

  'use strict';


})(jQuery);
